# Java3_Class4
Sample code for my students that shows the use of maven

This is for intended use with IntelliJ
"# Maven-to-Gradle-conversion" 
