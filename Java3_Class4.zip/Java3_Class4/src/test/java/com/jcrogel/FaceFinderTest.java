package com.jcrogel;

import org.junit.Test;

import static org.junit.Assert.*;

public class FaceFinderTest {
    @Test
    public void testStuff(){
        System.out.println("Tested");

    }

}